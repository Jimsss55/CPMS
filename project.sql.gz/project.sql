-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 11:45 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `cpms`
--

CREATE TABLE `cpms` (
  `VehicleType` varchar(255) DEFAULT NULL,
  `VehicleNumber` varchar(255) DEFAULT NULL,
  `VehicleAlphabet` varchar(255) DEFAULT NULL,
  `VehicleDigit` varchar(255) DEFAULT NULL,
  `VehicleCategory` varchar(255) DEFAULT NULL,
  `Date` date DEFAULT current_timestamp(),
  `Origin` varchar(255) DEFAULT NULL,
  `Destination` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cpms`
--

INSERT INTO `cpms` (`VehicleType`, `VehicleNumber`, `VehicleAlphabet`, `VehicleDigit`, `VehicleCategory`, `Date`, `Origin`, `Destination`) VALUES
('BP', '4', 'B', '1111', 'Light', '2022-05-22', 'Paro', 'Thimphu'),
('BP', '1', 'A', '0001', 'Light', '2022-05-22', 'Thimphu', 'Punakha');

-- --------------------------------------------------------

--
-- Table structure for table `driverdetails`
--

CREATE TABLE `driverdetails` (
  `LicenseAlphabet` varchar(255) NOT NULL,
  `LicenseNumber` varchar(255) NOT NULL,
  `CID` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `MobileNumber` varchar(255) NOT NULL,
  `Purpose` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driverdetails`
--

INSERT INTO `driverdetails` (`LicenseAlphabet`, `LicenseNumber`, `CID`, `Name`, `Gender`, `MobileNumber`, `Purpose`) VALUES
('G', '14532', '11748445678', 'Jimpa Jamtsho', 'Male', '17345678', 'Pilgrimage'),
('M', '12312', '10234567654', 'Tshering Dorji', 'Male', '17456278', 'Office Meeting');

-- --------------------------------------------------------

--
-- Table structure for table `passengerdetails`
--

CREATE TABLE `passengerdetails` (
  `PassengerCID` varchar(255) DEFAULT NULL,
  `PassengerName` varchar(255) DEFAULT NULL,
  `PassengerGender` varchar(255) DEFAULT NULL,
  `PassengerMobileNum` varchar(255) DEFAULT NULL,
  `PassengerPurpose` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passengerdetails`
--

INSERT INTO `passengerdetails` (`PassengerCID`, `PassengerName`, `PassengerGender`, `PassengerMobileNum`, `PassengerPurpose`) VALUES
('11672528902', 'Pema', 'Female', '77345678', 'Pilgrimage'),
('13423456789', 'Sangay Dorji', 'Male', '17345627', 'Office meeting'),
('17922342567', 'Sonam Dema', 'Female', '77123456', 'Office Meeting');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
